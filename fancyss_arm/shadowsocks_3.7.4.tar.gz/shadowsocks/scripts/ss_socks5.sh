#!/bin/sh

/koolshare/ss/socks5/socks5config.sh restart
